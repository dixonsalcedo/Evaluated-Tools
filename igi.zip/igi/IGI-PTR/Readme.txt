IGI/PTR (2003)

    Author(s): Ningning Hu, Peter Steenkiste
    Original Web site: http://www.cs.cmu.edu/~hnn/igi/