http://www.caida.org/tools/utilities/others/pathchar/

ftp://ftp.ee.lbl.gov/pathchar/

https://www.caida.org/tools/utilities/others/pathchar/pathcharnotes.html