Pathload (2003)

    Author(s): Mansih Jain e Constantinos Dovrolis.
    Original Web site: http://www.cc.gatech.edu/fac/Constantinos.Dovrolis/bw-est/pathload.html