#include "traceband_fn.h"

//===========================================================================
//=  Function to get the current time in seconds                            =
//===========================================================================
double get_time(void) 
{
  struct timeval tv;
  double cur_time;

  if (gettimeofday(&tv, NULL) < 0) exit(0);
  cur_time = (double)tv.tv_sec + ((double)tv.tv_usec/(double)1000000.0);
  return cur_time;
}

//===========================================================================
//=  Function to find the microseconds difference between two timeval values=
//===========================================================================

long timeval_diff(const struct timeval *t_now, const struct timeval *t_prev)
{
	long usecs_now;
	
	if (t_prev->tv_sec == 0 && t_prev->tv_usec == 0) return 0;
  usecs_now = (t_now->tv_sec - t_prev->tv_sec) * 1000000;
  usecs_now += (t_now->tv_usec - t_prev->tv_usec);
  return usecs_now;
}

//===========================================================================
//=  Function to convert a timeval value into seconds                       =
//===========================================================================
double timeval_to_seconds(const struct timeval *t)
{
  double timesec;

  timesec = (double)t->tv_sec + ((double)t->tv_usec/(double)1000000.0);
  return timesec;
}
//===========================================================================
//=  Function to from Donahoo and Calvert to exit with error                =
//===========================================================================
void DieWithError(char *errorMessage)
{
  perror(errorMessage);
  exit(1);
}
//===========================================================================
//=  Alarm signal handler function                                          =
//===========================================================================
void catch_alarm(int sig_num)
{
//  printf("Operation timed out. Exiting ...\n\n");
//  exit(0); // from a loop
  printf("Operation timed out. .\n\n");
}
//===========================================================================
//=  Prints the usage message for the sender                                =
//===========================================================================
void snd_usage(void)
{
  printf("\n---------------------------------------------------------------\n");
  printf("usage: ./traceband_snd -s <host name>\n");
  printf(" Options are:\n");
  printf("   -c  path capacity (default: %i bps)\n",PATHCAPACITY);
  printf("   -f  number of trains (default: %i)\n",NUM_TRAINS);
  printf("   -r  number of packets per train (default: %i)\n",PCK_TRAIN);
  printf("   -g  gap in a packet pair in microseconds (default: %lf)\n",
	(double)(PACKET_SIZE*8/PATHCAPACITY))*1000000;
  printf("   -i  gap between pairs in microseconds (default: %lf)\n",
		(double)(PACKET_SIZE*80/PATHCAPACITY))*1000000;
  printf("   -n  gap between trains in microseconds (default: %lf)\n",
		(double)(PACKET_SIZE*800/PATHCAPACITY))*1000000;
  printf("   -v  verbose\n");
  printf("   -h  to print this help\n");
  printf("\n---------------------------------------------------------------\n");
  exit(1);
}
//===========================================================================
//=  Spin for delta microseconds (adapted from spruce_snd.c)                =
//===========================================================================
void mysleep(long delta, struct timeval first)
{
  struct timeval target;
  struct timeval current_time;
  register long diff;

  target.tv_sec = first.tv_sec;
  target.tv_usec = first.tv_usec + delta;
  if(target.tv_usec >= 1000000){
    target.tv_sec++;
    target.tv_usec -= 1000000;
  }
  do{
    gettimeofday(&current_time,NULL);
    diff = (target.tv_sec - current_time.tv_sec) * 1000000 +
       (target.tv_usec - current_time.tv_usec);
  } while(diff > 0);
}

//===========================================================================
//=  Generate an exponential random number between 0 and 1                  =
//===========================================================================
double rand_exp(){

  double val = (double)rand()/(double)RAND_MAX;
  return -1*log(1-val);
}
//===========================================================================
//=  Generate a uniform random number between min and max                   =
//===========================================================================
double rand_uniform(int min, int max){

  double val = (double)rand()/(double)RAND_MAX;
  return min + (max - min) * val;
}

//===========================================================================
//= Returns the cluster labels of the data points in an array.              =
//= (adapted from http://cs.smu.ca/~r_zhang/code/kmeans.c)                  =
//= Parameters: array of data points (double **data)                        =
//=             number of data points (int n)                               =
//=             dimension (int m)                                           =
//=             desired number of clusters (int k)                          =
//=             error tolerance (double t) (suggested 0.0001)               =
//=             output address for the final centroids (double **centroids) =
//===========================================================================
int *k_means(double **data, int n, int m, int k, double t, double **centroids)
{
  /* output cluster label for each data point */
  int *labels = (int*)calloc(n, sizeof(int));
  int h, i, j; /* loop counters, of course :) */
  int *counts = (int*)calloc(k, sizeof(int)); /* size of each cluster */
  double old_error, error = DBL_MAX; /* sum of squared euclidean distance */
  double **c = centroids ? centroids : (double**)calloc(k, sizeof(double*));
  double **c1 = (double**)calloc(k, sizeof(double*)); /* temp centroids */

  assert(data && k > 0 && k <= n && m > 0 && t >= 0); /* for debugging */

  /* initialization */
  for (h = i = 0; i < k; h += n / k, i++) {
    c1[i] = (double*)calloc(m, sizeof(double));
    if (!centroids) c[i] = (double*)calloc(m, sizeof(double));
    /* pick k points as initial centroids */
    for (j = m; j-- > 0; c[i][j] = data[h][j]);
  }

  /* main loop */
  do {
    /* save error from last step */
    old_error = error, error = 0;
    /* clear old counts and temp centroids */
    for (i = 0; i < k; counts[i++] = 0) {
      for (j = 0; j < m; c1[i][j++] = 0);
    }

    for (h = 0; h < n; h++) {
      /* identify the closest cluster */
      double min_distance = DBL_MAX;
      for (i = 0; i < k; i++) {
        double distance = 0;
        for (j = m; j-- > 0; distance += pow(data[h][j] - c[i][j], 2));
        if (distance < min_distance) {
          labels[h] = i;
          min_distance = distance;
        }
      }
      /* update size and temp centroid of the destination cluster */
      for (j = m; j-- > 0; c1[labels[h]][j] += data[h][j]);
      counts[labels[h]]++;
      /* update standard error */
      error += min_distance;
    }

    for (i = 0; i < k; i++) { /* update all centroids */
      for (j = 0; j < m; j++) {
        c[i][j] = counts[i] ? c1[i][j] / counts[i] : c1[i][j];
      }
    }
  } while (fabs(error - old_error) > t);

   /* housekeeping */
  for (i = 0; i < k; i++) {
    if (!centroids) free(c[i]);
    free(c1[i]);
  }
  if (!centroids) {
    free(c);
  }
  free(c1);
  free(counts);
  return labels;
}
