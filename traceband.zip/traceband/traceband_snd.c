//=============================================== file = traceband_snd.c ====
//=  Sender side of trace bandwidth                                         =
//===========================================================================
//=  Notes:                                                                 =
//=    1) Complete application requires:                                    =
//=        * traceband_snd.c (Sender)                                       =
//=        * traceband_rcv.c (Receiver)                                     =
//=        * traceband_fn.c (Common functions)                              =
//=        * traceband_fn.h (Funcion declarations and constants definitions)=
//=    2) Output is generated in the receiver side                          =
//=-------------------------------------------------------------------------=
//=  Build: gcc traceband_snd.c traceband_fn.c                              =
//=-------------------------------------------------------------------------=
//=  Execute: traceband_snd <IP or host name for the target server>         =
//=-------------------------------------------------------------------------=
//=  Author: Cesar D. Guerrero                                              =
//=          University of South Florida                                    =
//=-------------------------------------------------------------------------=
//=  History: CDG (03/17/08) - Genesis                                      =
//===========================================================================

//----- Include files -------------------------------------------------------
#include "traceband_fn.h"

//----- Global variables ----------------------------------------------------
int verbose = FALSE;			 // verbose is off
int n_trains=NUM_TRAINS;		 // Number of trains
int p_train=PCK_TRAIN, samples;	 // Packets per train
int target_time = 0;     // Tool's running time. Zero means once.
int traceband_sock;              // Socket descriptor
int path_capacity=PATHCAPACITY;  // Capacity of the path in bps
int link_set = 0;
long pck_size=PACKET_SIZE;		 // Packet size is varied to identify packets
double pair_gap;               	 // Gap in a packet pair in us
double inpair_gap;               // Gap between pairs in us
double intrain_gap;			     // Gap between trains in us
char peer_actual[16];
char *rcv_IP;                    // IP address of receiver
struct sockaddr_in rcv_echo;     // Echo receiver address
struct sockaddr_in snd_echo;     // Echo sender address
struct hostent *rcv_info;        // Server information

//----- Function Prototypes -------------------------------------------------
void args_sender(int argc, char * argv[]);
int prep_sockets(void);

//===========================================================================
//=  Main program                                                           =
//===========================================================================

int main(int argc, char *argv[]) 
{
  unsigned int fromSize;   // In-out of address size for recvfrom()
  int rcv_msg_size;        // Length of received response
  int pck_num = 0;		     // Number of packet to be sent
  int train_cnt, pck_cnt;  // Packet and train counters
  int estim_num = 0;       // number of estimations
  void *snd_msg;		       // Data in the packet to be sent
  char rcv_msg[100];       // Buffer for receiving echoed string
  struct timeval timestamp, start_time, end_time;// Packet timestamping
  double run_time = 0, overhead;
  short int maximum_samples = TRUE;

  srand((unsigned int)time((time_t *)NULL)); // to reset the seed
  args_sender(argc, argv); // 
  prep_sockets();
  printf("%s:\nSending data to IP : %s via a %i bps path ..\n", argv[0], 
		rcv_IP, path_capacity);
  double shortest_inpair_gap = (pck_size+28)*2.*8.*1e6 / path_capacity / 0.05;
  inpair_gap = max(shortest_inpair_gap, inpair_gap);
  if (verbose)
  {
    printf("- Probing packet size : %i\n", pck_size+28);
    printf("- Path capacity       : %i\n", path_capacity);
    printf("- Number of trains    : %i\n", n_trains);
    printf("- Packets per train   : %i\n", p_train);
    printf("- Gap in a packet pair: %.2f microseconds\n", pair_gap);
    printf("- Gap between pairs   : %.2f microseconds\n", inpair_gap);
    printf("- Gap between trains  : %.2f microseconds\n", intrain_gap);
  }
  snd_msg = malloc(pck_size);		// allocate memory for packet to be sent
  do {
    maximum_samples = ((estim_num /30)*30 == estim_num) ? TRUE : FALSE;
    samples = maximum_samples ? p_train : min(p_train,80);
    gettimeofday(&start_time, NULL);  // estimation initial time
    // send packet pairs every inpair_gap microseconds
    for(train_cnt=1; train_cnt <= n_trains; train_cnt++)
    {
      for (pck_cnt=1; pck_cnt <= samples; pck_cnt++)
  	  {
	    pck_num++;
        *(((long*)snd_msg)+0) = htonl(pck_num);
        *(((long*)snd_msg)+1) = htonl(pck_size);
        gettimeofday(&timestamp, NULL);  // packet sending time
	    *(((long*)snd_msg)+2) = htonl(timestamp.tv_sec);
  	    *(((long*)snd_msg)+3) = htonl(timestamp.tv_usec);
	    // Now, send the packet to the receiver
        sendto(traceband_sock, snd_msg, pck_size, 0, (struct sockaddr *)
               &rcv_echo, sizeof(rcv_echo));
        if ((pck_cnt/2)*2 != pck_cnt) mysleep(pair_gap*1.2, timestamp); // sleep to send second packet
        // Exponential reparations between pairs (Poisson sampling)
  	    else mysleep(inpair_gap+rint(rand_exp()*inpair_gap), timestamp); // sleep while it is time to send the next pair
  	    //else mysleep(rint(rand_exp()*inpair_gap), timestamp); // sleep while it is time to send the next pair
	    }
	    mysleep(intrain_gap, timestamp); // gap between trains
    }
    // Send end of round key (pck_num is 0)
    *(((long*)snd_msg)+0) = htonl(0);
    *(((long*)snd_msg)+1) = htonl(path_capacity); // to tell the receiver about the path capacity
    sendto(traceband_sock, snd_msg, 1000, 0, (struct sockaddr *)
         &rcv_echo, sizeof(rcv_echo));
    // Recv a response
    fromSize = sizeof(snd_echo);
    signal(SIGALRM, catch_alarm);   // set a signal handler for ALRM signals
    alarm(10); 	                  // start a 10 seconds alarm
    rcv_msg_size = recvfrom(traceband_sock, rcv_msg, sizeof(rcv_msg), 0, 
       (struct sockaddr *) &snd_echo, &fromSize);
    alarm(0);    // remove the timer, now that we've got the user's input
    /* null-terminate the received data */
    printf("%s", rcv_msg);    // Print available bandwidth value estimated in the receiver side
    gettimeofday(&end_time, NULL);  // program final time
    run_time = timeval_diff(&end_time, &start_time);
    overhead=((n_trains*samples*8*(PACKET_SIZE+28))*1e6/run_time)/path_capacity*100;
    printf("Time: %.2f s\t", run_time/1e6);
    printf("Overhead: %.2f %%\n", overhead);
    target_time-=(run_time/1e6);
    //mysleep(inpair_gap*OFFTIME_MUL, end_time); // sleep until it is time for the next measurement
    //mysleep(1000000, end_time); // sleep until it is time for the next measurement
    estim_num++;
  } while (target_time>0);
  // Send end of transmission packet key (pck_size is 0)
  *(((long*)snd_msg)+1) = htonl(0);
  sendto(traceband_sock, snd_msg, 1000, 0, (struct sockaddr *)
      &rcv_echo, sizeof(rcv_echo));
  close(traceband_sock);
  return 1;
}

//----- Function Definitions ------------------------------------------------

//---------------------------------------------------------------------------
//- Set the sender program arguments                                        -
//---------------------------------------------------------------------------

void args_sender(int argc, char * argv[])
{
  int opt;

  // Default pck pair gap (us) is the time it takes to transmit a packet in 
  // the bottlenet link specified by "path_capacity"
  pair_gap=((double)(pck_size*8) / path_capacity) * 1e6;	
  inpair_gap=pair_gap*INPAIR_GAP_MUL;      // Gap between pairs in us
  intrain_gap=inpair_gap*INTRAIN_GAP_MUL;  // Gap between trains in us

  while((opt = getopt(argc, argv, "s:c:f:r:g:i:n:t:v")) != -1){
    switch(opt) {
      case 's':
        rcv_info = gethostbyname(optarg); // get server IP address
        if(rcv_info == NULL){
          fprintf(stderr, "Host not found: %s\n", optarg);
          exit(1);
        }
        rcv_IP = inet_ntoa(*(struct in_addr *)rcv_info->h_addr_list[0]);
        //copy away so future gethost* works?
        memcpy(peer_actual, rcv_info->h_addr, sizeof(rcv_echo.sin_addr.s_addr));
        break;
  	  case 'c':	// path's capacity
        {
          int len = strlen(optarg);
	      int mul = 1;
	      switch(optarg[len-1]) {
            case 'M':
  		    case 'm':
              mul = 1000 * 1000;
		      break;
		    case 'k':
		    case 'K':
			  mul = 1000;
		      break;
  		    case 'G':
	  	    case 'g':
		  	  mul = 1000 * 1000 * 1000;
		      break;
			default:
			  printf("Capacity units are K/M/G. It will be assumed in M (Mbps)\n");
			  mul = 1000 * 1000;
		      break;
		  }
  		  if(mul != 1) optarg[len-1] = 0;
	  	  path_capacity=atoi(optarg);
		  path_capacity*=mul;
		  if(path_capacity <= 0 || path_capacity > 1000000000) {
		    fprintf(stderr, "illegal path capacity: %d\n", path_capacity);
		    exit(1);
		  }
  		  link_set = 1;
	      pair_gap=((double)(pck_size*8) / path_capacity) * 1e6;	
          inpair_gap=pair_gap*INPAIR_GAP_MUL;      // Gap between pairs in us
          intrain_gap=inpair_gap*INTRAIN_GAP_MUL;  // Gap between trains in us
          break;
	      }
  	  case 'f':
	  	n_trains = atoi(optarg);
        if(n_trains <= 0){
          fprintf(stderr, "Number of trains must be greater than zero\n");
          exit(1);
        }
        break;
  	  case 'r':
	  	p_train = atoi(optarg);
        if(p_train <= 1){
          fprintf(stderr, "You must send at least two packets per train\n");
          exit(1);
        }
        if((p_train * n_trains) > MAX_NUMPCK){
          fprintf(stderr, "The maximum number of probing packets is: %d \n", MAX_NUMPCK);
          exit(1);
        }
        break;
  	  case 'g':
	  	pair_gap = atoi(optarg);
        if(pair_gap < 0){
          fprintf(stderr, "Gap between packets must be a positive number or zero\n");
          exit(1);
        }
        inpair_gap=pair_gap*10;
        intrain_gap=inpair_gap*10;
        break;
  	  case 'i':
	  	inpair_gap = atoi(optarg);
        if(inpair_gap < 0){
          fprintf(stderr, "Gap between packets must be a positive number or zero\n");
          exit(1);
        }
        break;
	  case 'n':
		intrain_gap = atoi(optarg);
        if(intrain_gap < 0){
          fprintf(stderr, "Gap between packets must be a positive number or zero\n");
          exit(1);
        }
        break;
	  case 't':
	    target_time = atoi(optarg);
        if(target_time < 0){
          fprintf(stderr, "Time must be >=0 (seconds)\n");
          exit(1);
        }
        break;
      case 'v':
        verbose = TRUE;
        break;
      case 'h':
	  	case '?':
      default:
        snd_usage();
    }
  }
  if(rcv_info==NULL){
    fprintf(stderr, "You must specify a receiver host\n");
    snd_usage();
  }
}

//---------------------------------------------------------------------------
//- Create and establish the UDP socket                                     -
//---------------------------------------------------------------------------

int prep_sockets()
{
  struct protoent *udp;
  int optval;
  int optsize;

  udp=getprotobyname("udp");
  bzero((void *)&snd_echo, sizeof(struct sockaddr_in));
  bzero((void *)&rcv_echo, sizeof(struct sockaddr_in));

  traceband_sock=socket(PF_INET,SOCK_DGRAM,udp->p_proto);
  if(traceband_sock < 0){
    perror("socket2x:");
    exit(1);
  }

  snd_echo.sin_family = AF_INET;
  snd_echo.sin_addr.s_addr = htonl(INADDR_ANY);
  snd_echo.sin_port = htons(0);
  
  rcv_echo.sin_family = AF_INET;
  memcpy((void*)&(rcv_echo.sin_addr.s_addr), peer_actual,
        sizeof(rcv_echo.sin_addr.s_addr));
  rcv_echo.sin_port = htons(SERVER_PORT);

  //12 bytes for payload... will this be combined or not?*/
  optval = PACKET_SIZE;
  optsize = sizeof(optval);
  if(setsockopt(traceband_sock,SOL_SOCKET, SO_SNDBUF, &optval, optsize) < 0){
    perror("traceband: SNDBUF");
    exit(1);
  }
  if(bind(traceband_sock, (struct sockaddr*)&snd_echo,
         sizeof(snd_echo)) < 0){
    perror("udp pair bind");
    exit(1);
  }
  if(connect(traceband_sock, (struct sockaddr*)&rcv_echo,
            sizeof(rcv_echo)) < 0){
    perror("udp gap connect");
  }
  return 0;
}
