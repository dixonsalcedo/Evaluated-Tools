//=============================================== file = traceband_rcv.c ====
//=  Receiver side of trace bandwidth                                       =
//===========================================================================
//=  Notes:                                                                 =
//=    1) Complete application requires:                                    =
//=        * traceband_snd.c (Sender)                                       =
//=        * traceband_rcv.c (Receiver)                                     =
//=        * traceband_fn.c (Common functions)                              =
//=        * traceband_fn.h (Funcion declarations and constants definitions)=
//=    2) Output to trace file that has the pairs correctly received:       =
//=    	    <pckpair #> <2nd packet timestamp> <1st pcksize> <d_in> <d_out> =
//=-------------------------------------------------------------------------=
//= Example output:                                                         =
//=                                                                         =
//=-------------------------------------------------------------------------=
//=  Build: gcc traceband_rcv.c traceband_fn.c                              =
//=-------------------------------------------------------------------------=
//=  Execute: traceband_rcv <trace file name>                               =
//=-------------------------------------------------------------------------=
//=  Author: Cesar D. Guerrero                                              =
//=          University of South Florida                                    =
//=-------------------------------------------------------------------------=
//=  History: CDG (04/17/07) - Genesis                                      =
//=           CDG (09/11/07) - Timestamps by SO_TIMESTAMP                   =
//===========================================================================


//----- Include files -------------------------------------------------------
#include "traceband_fn.h"
#include "hmm.h"

//----- Function Prototypes -------------------------------------------------
trace *dump_array(long, int*, int, trace *);
void dump_file(char *, trace *);
int prep_sockets(void);
void memory_dump(char *, int); // dump results in file_name

//----- Global variables-----------------------------------------------------
int traceband_sock;           // Socket descriptor
int i, j;                     // For loops
char peer_actual[16];
struct sockaddr_in snd_echo; // Echo sender address
struct sockaddr_in rcv_echo; // Echo receiver address
int *symbol;
short *sign;
int *pck_cnt;                // Number of packets received
int *pair_cnt;               // Number of valid pairs received
traceband_pkt *traceband_table;

//===========================================================================
//=  Main program                                                           =
//===========================================================================
int main(int argc, char *argv[])
{
  static const int tmp_buff_size=2000;  // Size of temporal buffer
  unsigned int rcv_msg_size;    // Size of received message
  long pck_size;                // Packet size as specified by sender
  long path_capacity;
  trace *trace_array;
  trace *tb_array;
  long pck_num=0;               // Packet number as specified by sender
  char ctrl[CMSG_SPACE(sizeof(struct timeval))];
  char snd_msg[100];            // Message to send back
  char *tmp_buff;               // Temporal buffer for message received
  struct msghdr rcv_msg;        // Received message structure
  struct iovec iov;             // Data storage structure for I/O
  struct cmsghdr *crcv_msg = (struct cmsghdr *)&ctrl;
  struct timeval rcv_time, snd_time;
  HMM	hmm;
  int	N;
	int	M;
  double state;
  FILE	*fp;
  int seed;

  if(argc<2) {
	  printf("usage : %s <trace file name>\n", argv[0]);
	  exit(0);
  }

  //Read hmm model (N, M, and B matrix) from file
  fp = fopen("hmminitfile", "r");
	if (fp == NULL) {
		fprintf(stderr, "Error: File hmminitfile not found \n");
    exit (1);
	}
	ReadHMM(fp, &hmm);
	fclose(fp);

  if (prep_sockets() != 0) DieWithError("Socket initialization failed");
  printf("%s: waiting for data on UDP port %u\n\n", argv[0],SERVER_PORT);

  symbol = (int *) ivector(1, MAX_NUMPCK);
  sign = (short *) ivector(1, MAX_NUMPCK);
  // Allocate memory to number packets from the sender
  pck_cnt = malloc(sizeof(int));
  assert(pck_cnt != NULL);
  // Allocate memory to number valid pairs from the sender
  pair_cnt = malloc(sizeof(int));
  assert(pair_cnt != NULL);
  // Allocate memory to store at most MAX_NUMPCK packets from the sender
  traceband_table = malloc(sizeof(traceband_pkt) * MAX_NUMPCK);
  assert(traceband_table != NULL);
  // Allocate memory to store the packet from the sender
  tmp_buff=malloc(tmp_buff_size);
  assert(tmp_buff!=NULL);
  // Allocate memory to store at most MAX_NUMPCK packets
  tb_array = malloc(sizeof(trace) * MAX_NUMPCK);
  assert(tb_array != NULL);

  // fill out the array with zeros
  bzero(traceband_table, sizeof(traceband_pkt) * MAX_NUMPCK);
  bzero(&rcv_msg, sizeof(rcv_msg));
  bzero(&rcv_time, sizeof(rcv_time));
  bzero(ctrl, CMSG_SPACE(sizeof(struct timeval)));
  bzero(tb_array, sizeof(trace) * MAX_NUMPCK);

  iov.iov_base = tmp_buff;        // base address of the data storage area
  iov.iov_len = tmp_buff_size;    // size of the data storage area in bytes
  rcv_msg.msg_iov = &iov;
  rcv_msg.msg_iovlen = 1;
  rcv_msg.msg_namelen = sizeof(snd_echo);
  rcv_msg.msg_name = &snd_echo;
  rcv_msg.msg_control = (caddr_t) ctrl;
  rcv_msg.msg_controllen = sizeof(ctrl);

  srand((unsigned int)time((time_t *)NULL)); // to reset the seed
  // Estimation of initial state probabilities:
  hmm.pi = (double *) dvector(1, hmm.N);
  for(i=1;i<=hmm.N;i++) hmm.pi[i]=rand_uniform(0,1); // random initial values
  hmm.pi = normalize_vector(hmm.pi, hmm.N);

  //// Estimation of initial state transition probabilities:
  hmm.A = (double **) dmatrix(1, hmm.N, 1, hmm.N);
  hmm.A = onestepTransMatrix(hmm.A, hmm.N);
  //InitHMM(&hmm, hmm.N, hmm.M, seed);
  *pck_cnt=0;
  // Get and timestamp packets from the sender
  while (TRUE) 
  {
    if((rcv_msg_size=recvmsg(traceband_sock,&rcv_msg, 0)) < 0)
        DieWithError("recv() failed");

  	if (crcv_msg->cmsg_level == SOL_SOCKET &&
        crcv_msg->cmsg_type == SCM_TIMESTAMP &&
        crcv_msg->cmsg_len == CMSG_LEN(sizeof(struct timeval)))
	  { // Copy to avoid alignment problems
      memcpy(&rcv_time,CMSG_DATA(crcv_msg),sizeof(rcv_time));
    } else {
      gettimeofday(&rcv_time, NULL);
      fprintf (stderr, "didn't get timestamp data!\n");
    }
    pck_num = ntohl(*(((long*)tmp_buff)+0));
    pck_size = ntohl(*(((long*)tmp_buff)+1));
    snd_time.tv_sec = ntohl(*(((long*)tmp_buff)+2));
    snd_time.tv_usec = ntohl(*(((long*)tmp_buff)+3));
	if (pck_size == 0) break; // No more packets to receive
    if (pck_num == 0) { // Ready to perform the estimation
      path_capacity=pck_size; //weird but last received packet has the path capacity in 
                          //the packet size field.
      // Dump data into a matrix and calculate available bandwidth values
      trace_array=dump_array(path_capacity, pck_cnt, hmm.M, tb_array);
    	PrintHMM(stdout, &hmm);
      //state=mean(symbol, *pair_cnt);
      state=hmmest(sign, symbol, &hmm, *pair_cnt);
      // Dump calculated values into a file
      dump_file(argv[1], trace_array);
      sprintf(snd_msg, "AvBw: %.0f Mbps\t", (((double)10/(double)hmm.N)*state)/10000000*path_capacity);
      sendto(traceband_sock, snd_msg, (strlen(snd_msg)+1), 0, 
         (struct sockaddr *) &snd_echo, sizeof(snd_echo));
      printf("Available Bandwidth: %.2f Mbps\n", (((double)10/(double)hmm.N)*state)/10000000*path_capacity);
      //printf("Available Bandwidth: %.2f bps\n", ((double)(10/hmm.N)*state)/10*path_capacity);
      *pck_cnt=0;
      //srand((unsigned int)time((time_t *)NULL)); // to reset the seed
      //// Estimation of initial state probabilities:
      //hmm.pi = (double *) dvector(1, hmm.N);
      //for(i=1;i<=hmm.N;i++) hmm.pi[i]=rand_uniform(0,1); // random initial values
      //hmm.pi = normalize_vector(hmm.pi, hmm.N);

      //// Estimation of initial state transition probabilities:
      //hmm.A = (double **) dmatrix(1, hmm.N, 1, hmm.N);
      //hmm.A = onestepTransMatrix(hmm.A, hmm.N);
      continue;
    }
    if(*pck_cnt < MAX_NUMPCK){
      traceband_table[*pck_cnt].num = pck_num;
      traceband_table[*pck_cnt].size = pck_size;
      memcpy(&(traceband_table[*pck_cnt].snd_time), &snd_time, sizeof(struct timeval));
	    memcpy(&(traceband_table[*pck_cnt].rcv_time), &rcv_time, sizeof(struct timeval));
      (*pck_cnt)++;	// a new packet was received
	  }
  } // end of while loop
  FreeHMM(&hmm);
	free_ivector(symbol, 1, MAX_NUMPCK);
  close(traceband_sock);
  return 0;
}

//----- Function Definitions --------------------------------------------------

//---------------------------------------------------------------------------
//- Create and establish the UDP socket                                     -
//---------------------------------------------------------------------------

int prep_sockets()
{
  struct protoent *udp;
  int opt;
  int one=1;

  udp=getprotobyname("udp");
  assert(udp != NULL);

  //need accurate timings on recieved packets here
  bzero((void *)&snd_echo, sizeof(struct sockaddr_in));
  bzero((void *)&rcv_echo, sizeof(struct sockaddr_in));
  
  traceband_sock=socket(PF_INET,SOCK_DGRAM,udp->p_proto);
  if(traceband_sock < 0){
    perror("socket3:");
    exit(1);
  }

  rcv_echo.sin_family = AF_INET;
  rcv_echo.sin_addr.s_addr = htonl(INADDR_ANY);
  rcv_echo.sin_port = htons(SERVER_PORT);

  if(bind(traceband_sock, (struct sockaddr*)&rcv_echo,
	  sizeof(rcv_echo)) < 0){
    perror("udp bind 2");
    exit(1);
  }

  /*set SO_TIMESTAMP option*/
  if(setsockopt(traceband_sock, SOL_SOCKET, SO_TIMESTAMP,
      &one, sizeof(one)) < 0){
    perror("setsockopt(SO_TIMESTAMP) failed rcv_echo:");
  }
  return 0;
}

//---------------------------------------------------------------------------
//- Dump data from memory to a file                                         -
//---------------------------------------------------------------------------
void dump_file(char *file_name, trace *dumparray)
{
  FILE *disp;                     // file to store dispersions
  int i;

  // Open file for writting
  if ((disp = fopen(file_name, "w+")) == NULL)
  	DieWithError("Unable to open the trace file\n");

  for( i=0 ; i < (*pair_cnt) ; i++ ) // start with the second captured packet
  {
    fprintf(disp, "%5.2d %8.2f %d %d %d\n", dumparray[i].timestamp, dumparray[i].av_bw, 
      dumparray[i].delta_in, dumparray[i].delta_out, symbol[i+1]);
  }
  fflush(disp);
  fclose(disp);
}

//---------------------------------------------------------------------------
//- Dump packet data from memory to an array                                -
//---------------------------------------------------------------------------
trace* dump_array(long capacity, int *cnt, int M, trace* traceband_array)
{
  //const int arraysize = &cnt;
  //trace *traceband_array;
  double delta_in, delta_out, jitter, strain, avg, sum=0;
  int i;

  *pair_cnt=0;
  // Allocate memory to store at most MAX_NUMPCK packets
  //traceband_array = malloc(sizeof(trace) * MAX_NUMPCK);
  //assert(traceband_array != NULL);
  // fill out the array with zeros
  bzero(traceband_array, sizeof(trace) * MAX_NUMPCK);

  for( i=1 ; i < *cnt ; i++ ) // start with the second captured packet
  {
	  // if (two consecutive packets) && (second one is odd))
	  if ((traceband_table[i].num-traceband_table[i-1].num == 1) &&
	  (traceband_table[i].num /2*2 == traceband_table[i].num)) 
	  {
      delta_in = timeval_diff(&(traceband_table[i].snd_time), 
        &(traceband_table[i-1].snd_time));
	    delta_out = timeval_diff(&(traceband_table[i].rcv_time), 
        &(traceband_table[i-1].rcv_time));
      jitter = max((delta_out-delta_in),0); // only positive values for jitter
      strain = jitter/delta_in;
      strain = strain > 1.7 ? 1.7 : strain; // according to spruce, to ignore preemptions
      (*pair_cnt)++;
      traceband_array[(*pair_cnt)-1].timestamp = timeval_diff(&(traceband_table[i].rcv_time), 
        &(traceband_table[0].rcv_time));
      traceband_array[(*pair_cnt)-1].av_bw = capacity * (1-strain); // Available bandwidth
	  traceband_array[(*pair_cnt)-1].delta_in = delta_in;
      traceband_array[(*pair_cnt)-1].delta_out = delta_out;
      symbol[*pair_cnt] = (int) ceil(M * fabs(1-strain)); //  A number from 1 to M
      sign[*pair_cnt] = strain > 1 ? -1 : 1; // multiplier
	    //average value (just to compare with spruce)
	    //sum += traceband_array[(*pair_cnt)-1].av_bw;
	    //avg = sum / *pair_cnt;
	    //avg = max(avg, 0);
    }
  }
  //printf("Spruce: %.4f\n",avg);
  return traceband_array;
}


void ReadHMM(FILE *fp, HMM *phmm)
{
	int i, j, k;

	fscanf(fp, "M= %d\n", &(phmm->M)); 

	fscanf(fp, "N= %d\n", &(phmm->N)); 

	//fscanf(fp, "A:\n");
	//phmm->A = (double **) dmatrix(1, phmm->N, 1, phmm->N);
	//for (i = 1; i <= phmm->N; i++) { 
	//	for (j = 1; j <= phmm->N; j++) {
	//		fscanf(fp, "%lf", &(phmm->A[i][j])); 
	//	}
	//	fscanf(fp,"\n");
	//}

	fscanf(fp, "B:\n");
	phmm->B = (double **) dmatrix(1, phmm->N, 1, phmm->M);
	for (j = 1; j <= phmm->N; j++) { 
		for (k = 1; k <= phmm->M; k++) {
		fscanf(fp, "%lf", &(phmm->B[j][k])); 
		}
		fscanf(fp,"\n");
	}

	//fscanf(fp, "pi:\n");
	//phmm->pi = (double *) dvector(1, phmm->N);
	//for (i = 1; i <= phmm->N; i++) 
	//	fscanf(fp, "%lf", &(phmm->pi[i])); 

}
