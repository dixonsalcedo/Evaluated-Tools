/*
**      Author: Tapas Kanungo, kanungo@cfar.umd.edu
**      Date:   22 February 1988 
**      File:   esthmm.c
**      Purpose: estimate HMM parameters from observation. 
**      Organization: University of Maryland
**
**      $Id: esthmm.c,v 1.1 1998/02/23 07:49:45 kanungo Exp kanungo $
*/

#include "traceband_fn.h"
#include "hmm.h"

//===========================================================================
//=  Creates a normalized matrix which rows are one-step and sum is 1       =
//===========================================================================
double **onestepTransMatrix(double **A, int N)
{
  int i, j;
  double *tot;
  // This loop assign random numbers to the onstep matrix values
  // and summarizes the rows
  tot = (double *) dvector(1, N);
  for(i=1;i<=N;i++)
  {
    tot[i]=0.0;
    for(j=1;j<=N;j++) 
    {
      if (abs(i-j)>1) A[i][j]=0.0;
      else {
        A[i][j]=rand_uniform(0,1);
        tot[i]=tot[i]+A[i][j];
      }
    }
  }
  //Now, divide each element by the corresp. row total (to make the row total=1)
  for(i=1;i<=N;i++)
  {
    for(j=1;j<=N;j++) {
      A[i][j]=A[i][j]/tot[i];
    }
  }
  return A;
}

//===========================================================================
//=  Returns the mean value of a vector                                     =
//===========================================================================
double mean(int* A, int N)
{
  int i;
  double tot=0.0;
  for(i=1;i<=N;i++) tot+=A[i];
  return (double)tot/N;
}

//===========================================================================
//=  Creates a normalized vector which sum is 1                             =
//===========================================================================
double *normalize_vector(double* A, int N)
{
  int i;
  double tot=0.0;
  for(i=1;i<=N;i++) tot+=A[i];
  for(i=1;i<=N;i++) A[i]=A[i]/tot;
  return A;
}

//===========================================================================
//=  Creates a normalized matrix which row sums are 1                       =
//===========================================================================
double **normalize_matrix(double** A, int N, int M)
{
  int i,j;
  double *tot;
  tot = (double *) dvector(1, N);
  for(i=1;i<=N;i++)
  {
    tot[i]=0.0;
    for(j=1;j<=N;j++) tot[i]=tot[i]+A[i][j];
  }
  for(i=1;i<=N;i++)
  {
    for(j=1;j<=M;j++) A[i][j]=A[i][j]/tot[i];
  }
  return A;
}

//===========================================================================
//= Baum Welch by Tapas Kanungo from University of Maryland                 =
//===========================================================================
void BaumWelch(HMM *phmm, int T, int *O, double **alpha, double **beta,
	double **gamma, int *pniter, 
	double *plogprobinit, double *plogprobfinal)
{
  int	i, j, k;
  int	t, l = 0;
  double	logprobf, logprobb,  threshold;
  double	numeratorA, denominatorA;
  double	numeratorB, denominatorB;
  double ***xi, *scale;
  double delta, deltaprev, logprobprev;

  deltaprev = 10e-70;
  xi = AllocXi(T, phmm->N);
  scale = dvector(1, T);

  ForwardWithScale(phmm, T, O, alpha, scale, &logprobf);
  *plogprobinit = logprobf; /* log P(O |intial model) */
  BackwardWithScale(phmm, T, O, beta, scale, &logprobb);
  ComputeGamma(phmm, T, alpha, beta, gamma);
  ComputeXi(phmm, T, O, alpha, beta, xi);
  logprobprev = logprobf;

  do {	
	/* reestimate frequency of state i in time t=1 */
    for (i = 1; i <= phmm->N; i++) 
	  phmm->pi[i] = .001 + .999*gamma[1][i];

    /* reestimate transition matrix  and symbol prob in each state */
    for (i = 1; i <= phmm->N; i++) { 
	  denominatorA = 0.0;
      for (t = 1; t <= T - 1; t++) 
        denominatorA += gamma[t][i];
      for (j = 1; j <= phmm->N; j++) {
        numeratorA = 0.0;
        for (t = 1; t <= T - 1; t++) 
          numeratorA += xi[t][i][j];
          phmm->A[i][j] = .001 + .999*numeratorA/denominatorA;
      }
      denominatorB = denominatorA + gamma[T][i]; 
      for (k = 1; k <= phmm->M; k++) {
        numeratorB = 0.0;
        for (t = 1; t <= T; t++) {
          if (O[t] == k) numeratorB += gamma[t][i];
        }
        // Comment here to avoid B estimation ...
        //phmm->B[i][k] = .001 + .999*numeratorB/denominatorB;
      }
	} 
    ForwardWithScale(phmm, T, O, alpha, scale, &logprobf);
    BackwardWithScale(phmm, T, O, beta, scale, &logprobb);
    ComputeGamma(phmm, T, alpha, beta, gamma);
    ComputeXi(phmm, T, O, alpha, beta, xi);

    /* compute difference between log probability of two iterations */
    delta = logprobf - logprobprev; 
    logprobprev = logprobf;
    l++;
  }
  while (delta > DELTA); /* if log probability does not 
                                  change much, exit */ 
 *pniter = l;
  *plogprobfinal = logprobf; /* log P(O|estimated model) */
  FreeXi(xi, T, phmm->N);
  free_dvector(scale, 1, T);
}

//===========================================================================
//= HMM initialization                                                      =
//===========================================================================
void InitHMM(HMM *phmm, int N, int M, int seed)
{
  int i, j, k;
  double sum;
  /* initialize random number generator */

  hmmsetseed(seed);       	
  phmm->M = M;
  phmm->N = N;
  phmm->A = (double **) dmatrix(1, phmm->N, 1, phmm->N);
  for (i = 1; i <= phmm->N; i++) {
    sum = 0.0;
    for (j = 1; j <= phmm->N; j++) {
      phmm->A[i][j] = hmmgetrand(); 
      sum += phmm->A[i][j];
    }
    for (j = 1; j <= phmm->N; j++) phmm->A[i][j] /= sum;
  }
//  phmm->B = (double **) dmatrix(1, phmm->N, 1, phmm->M);
//  for (j = 1; j <= phmm->N; j++) {
//    sum = 0.0;	
//    for (k = 1; k <= phmm->M; k++) {
//      phmm->B[j][k] = hmmgetrand();
//      sum += phmm->B[j][k];
//    }
//    for (k = 1; k <= phmm->M; k++) phmm->B[j][k] /= sum;
//  }
  phmm->pi = (double *) dvector(1, phmm->N);
  sum = 0.0;
  for (i = 1; i <= phmm->N; i++) {
    phmm->pi[i] = hmmgetrand(); 
    sum += phmm->pi[i];
  }
  for (i = 1; i <= phmm->N; i++) phmm->pi[i] /= sum;
}

//===========================================================================
//= T is the number of observations                                         =
//= ABobserv has the obsetvations: {timestamp, av_bw}                       =
//===========================================================================
double hmmest(short *sign, int *ABobs, HMM *ABhmm, int T)
{
  double **alpha; 
  double **beta;
  double **gamma;
  int *q;	/* state sequence q[1..T] */
  int c;
  int seed; /* seed for random number generator */
  char *hmminitfile;
  int niter;
  double logprobinit, logprobfinal;
  extern int optind, opterr, optopt;
  double **delta;
  int **psi;
  double proba, logproba; 

  /* allocate memory */
  alpha = dmatrix(1, T, 1, ABhmm->N);
  beta = dmatrix(1, T, 1, ABhmm->N);
  gamma = dmatrix(1, T, 1, ABhmm->N);

  BaumWelch(ABhmm, T, ABobs, alpha, beta, gamma, &niter, 
		&logprobinit, &logprobfinal);
  q = ivector(1,T);
  delta = dmatrix(1, T, 1, ABhmm->N);
  psi = imatrix(1, T, 1, ABhmm->N);
  Viterbi(ABhmm, T, ABobs, delta, psi, q, &proba); 

  fprintf(stdout, "Observations:\n");
  PrintSequence(stdout, T, ABobs);
  fprintf(stdout, "Optimal state sequence:\n");
  PrintSequence(stdout, T, q);

  /* free memory */
  free_dmatrix(alpha, 1, T, 1, ABhmm->N);
  free_dmatrix(beta, 1, T, 1, ABhmm->N);
  free_dmatrix(gamma, 1, T, 1, ABhmm->N);
  double tot=0.0;
  for(c=1;c<=T;c++) tot+=(q[c]*sign[c]);
  return (double)tot/T;
  //return mean(q,T);
}

//===========================================================================
//= Release HMM memory                                                      =
//===========================================================================
void FreeHMM(HMM *phmm)
{
  free_dmatrix(phmm->A, 1, phmm->N, 1, phmm->N);
  free_dmatrix(phmm->B, 1, phmm->N, 1, phmm->M);
  free_dvector(phmm->pi, 1, phmm->N);
}

//===========================================================================
//= Compute Gamma                                                           =
//===========================================================================
void ComputeGamma(HMM *phmm, int T, double **alpha, double **beta, 
	double **gamma)
{
  int i, j;
  int t;
  double denominator;

  for (t = 1; t <= T; t++) {
    denominator = 0.0;
    for (j = 1; j <= phmm->N; j++) {
      gamma[t][j] = alpha[t][j]*beta[t][j];
      denominator += gamma[t][j];
    }
    for (i = 1; i <= phmm->N; i++) 
      gamma[t][i] = gamma[t][i]/denominator;
  }
}

//===========================================================================
//= Compute Xi                                                              =
//===========================================================================
void ComputeXi(HMM* phmm, int T, int *O, double **alpha, double **beta, 
	double ***xi)
{
  int i, j;
  int t;
  double sum;

  for (t = 1; t <= T - 1; t++) {
    sum = 0.0;	
    for (i = 1; i <= phmm->N; i++) 
      for (j = 1; j <= phmm->N; j++) {
        xi[t][i][j] = alpha[t][i]*beta[t+1][j]
        *(phmm->A[i][j])
        *(phmm->B[j][O[t+1]]);
        sum += xi[t][i][j];
      }
    for (i = 1; i <= phmm->N; i++) 
      for (j = 1; j <= phmm->N; j++) 
        xi[t][i][j]  /= sum;
  }
}

//===========================================================================
//= Forward algorithm                                                       =
//===========================================================================
void ForwardWithScale(HMM *phmm, int T, int *O, double **alpha, 
	double *scale, double *pprob)
/*  pprob is the LOG probability */
{
  int i, j; 	/* state indices */
  int t;	/* time index */
  double sum;	/* partial sum */

  /* 1. Initialization */
  scale[1] = 0.0;	
  for (i = 1; i <= phmm->N; i++) {
    alpha[1][i] = phmm->pi[i]* (phmm->B[i][O[1]]);
    scale[1] += alpha[1][i];
  }
  for (i = 1; i <= phmm->N; i++) 
    alpha[1][i] /= scale[1]; 
	
  /* 2. Induction */
  for (t = 1; t <= T - 1; t++) {
    scale[t+1] = 0.0;
    for (j = 1; j <= phmm->N; j++) {
      sum = 0.0;
      for (i = 1; i <= phmm->N; i++) 
        sum += alpha[t][i]* (phmm->A[i][j]); 
      alpha[t+1][j] = sum*(phmm->B[j][O[t+1]]);
      scale[t+1] += alpha[t+1][j];
    }
    for (j = 1; j <= phmm->N; j++) 
      alpha[t+1][j] /= scale[t+1]; 
  }

  /* 3. Termination */
  *pprob = 0.0;
  for (t = 1; t <= T; t++)
    *pprob += log(scale[t]);
}

//===========================================================================
//= Backward algorithm                                                       =
//===========================================================================
void BackwardWithScale(HMM *phmm, int T, int *O, double **beta, 
	double *scale, double *pprob)
{
  int i, j;   /* state indices */
  int t;      /* time index */
  double sum;
 
  /* 1. Initialization */
  for (i = 1; i <= phmm->N; i++)
    beta[T][i] = 1.0/scale[T]; 
 
  /* 2. Induction */
  for (t = T - 1; t >= 1; t--) {
    for (i = 1; i <= phmm->N; i++) {
      sum = 0.0;
      for (j = 1; j <= phmm->N; j++)
       	sum += phmm->A[i][j] * 
					(phmm->B[j][O[t+1]])*beta[t+1][j];
      beta[t][i] = sum/scale[t];
    }
  }
}

//===========================================================================
//= Viterbi algorithm                                                       =
//===========================================================================
void Viterbi(HMM *phmm, int T, int *O, double **delta, int **psi, 
	int *q, double *pprob)
{
	int 	i, j;	/* state indices */
	int  	t;	/* time index */	

	int	maxvalind;
	double	maxval, val;

	/* 1. Initialization  */
	
	for (i = 1; i <= phmm->N; i++) {
		delta[1][i] = phmm->pi[i] * (phmm->B[i][O[1]]);
		psi[1][i] = 0;
	}	

	/* 2. Recursion */
	
	for (t = 2; t <= T; t++) {
		for (j = 1; j <= phmm->N; j++) {
			maxval = 0.0;
			maxvalind = 1;	
			for (i = 1; i <= phmm->N; i++) {
				val = delta[t-1][i]*(phmm->A[i][j]);
				if (val > maxval) {
					maxval = val;	
					maxvalind = i;	
				}
			}
			
			delta[t][j] = maxval*(phmm->B[j][O[t]]);
			psi[t][j] = maxvalind; 

		}
	}

	/* 3. Termination */

	*pprob = 0.0;
	q[T] = 1;
	for (i = 1; i <= phmm->N; i++) {
                if (delta[T][i] > *pprob) {
			*pprob = delta[T][i];	
			q[T] = i;
		}
	}

	/* 4. Path (state sequence) backtracking */

	for (t = T - 1; t >= 1; t--)
		q[t] = psi[t+1][q[t+1]];
}

//===========================================================================
//= Print State sequence                                                    =
//===========================================================================
void PrintSequence(FILE *fp, int T, int *O)
{
  int i;
 
  fprintf(fp, "T= %d\n", T);
  for (i=1; i <= T; i++) fprintf(fp,"%d ", O[i]);
	printf("\n");
 
}

//===========================================================================
//= Print HMM model                                                         =
//===========================================================================
void PrintHMM(FILE *fp, HMM *phmm)
{
  int i, j, k;

  fprintf(fp, "M= %d\n", phmm->M); 
  fprintf(fp, "N= %d\n", phmm->N); 
 
  fprintf(fp, "A:\n");
  for (i = 1; i <= phmm->N; i++) {
    for (j = 1; j <= phmm->N; j++) {
      fprintf(fp, "%.2f ", phmm->A[i][j] );
		}
		fprintf(fp, "\n");
	}
 
	fprintf(fp, "B:\n");
  for (j = 1; j <= phmm->N; j++) {
    for (k = 1; k <= phmm->M; k++){
      fprintf(fp, "%.2f ", phmm->B[j][k]);
		}
		fprintf(fp, "\n");
	}
 
	fprintf(fp, "pi:\n");
  for (i = 1; i <= phmm->N; i++) {
    fprintf(fp, "%.2f ", phmm->pi[i]);
	}
	fprintf(fp, "\n\n");
}

//===========================================================================
//= Memory Allocation Functions                                             =
//===========================================================================
double *** AllocXi(int T, int N)
{
  int t;
  double ***xi;

  xi = (double ***) malloc(T*sizeof(double **));
  xi --;
  for (t = 1; t <= T; t++)
    xi[t] = dmatrix(1, N, 1, N);
  return xi;
}

float *vector(nl,nh)
int nl,nh;
{
	float *v;
	v=(float *)calloc((unsigned) (nh-nl+1),sizeof(float));
	if (!v) nrerror("allocation failure in vector()");
	return v-nl;
}

int *ivector(nl,nh)
int nl,nh;
{
	int *v;
	v=(int *)calloc((unsigned) (nh-nl+1),sizeof(int));
	if (!v) nrerror("allocation failure in ivector()");
	return v-nl;
}

double *dvector(nl,nh)
int nl,nh;
{
	double *v;
	v=(double *)calloc((unsigned) (nh-nl+1),sizeof(double));
	if (!v) nrerror("allocation failure in dvector()");
	return v-nl;
}

float **matrix(nrl,nrh,ncl,nch)
int nrl,nrh,ncl,nch;
{
	int i;
	float **m;
	m=(float **) calloc((unsigned) (nrh-nrl+1),sizeof(float*));
	if (!m) nrerror("allocation failure 1 in matrix()");
	m -= nrl;
	for(i=nrl;i<=nrh;i++) {
		m[i]=(float *) calloc((unsigned) (nch-ncl+1),sizeof(float));
		if (!m[i]) nrerror("allocation failure 2 in matrix()");
		m[i] -= ncl;
	}
	return m;
}

double **dmatrix(nrl,nrh,ncl,nch)
int nrl,nrh,ncl,nch;
{
	int i;
	double **m;
	m=(double **) calloc((unsigned) (nrh-nrl+1),sizeof(double*));
	if (!m) nrerror("allocation failure 1 in dmatrix()");
	m -= nrl;
	for(i=nrl;i<=nrh;i++) {
		m[i]=(double *) calloc((unsigned) (nch-ncl+1),sizeof(double));
		if (!m[i]) nrerror("allocation failure 2 in dmatrix()");
		m[i] -= ncl;
	}
	return m;
}

int **imatrix(nrl,nrh,ncl,nch)
int nrl,nrh,ncl,nch;
{
	int i,**m;
	m=(int **)calloc((unsigned) (nrh-nrl+1),sizeof(int*));
	if (!m) nrerror("allocation failure 1 in imatrix()");
	m -= nrl;
	for(i=nrl;i<=nrh;i++) {
		m[i]=(int *)calloc((unsigned) (nch-ncl+1),sizeof(int));
		if (!m[i]) nrerror("allocation failure 2 in imatrix()");
		m[i] -= ncl;
	}
	return m;
}

float **submatrix(a,oldrl,oldrh,oldcl,oldch,newrl,newcl)
float **a;
int oldrl,oldrh,oldcl,oldch,newrl,newcl;
{
	int i,j;
	float **m;
	m=(float **) calloc((unsigned) (oldrh-oldrl+1),sizeof(float*));
	if (!m) nrerror("allocation failure in submatrix()");
	m -= newrl;
	for(i=oldrl,j=newrl;i<=oldrh;i++,j++) m[j]=a[i]+oldcl-newcl;
	return m;
}

//===========================================================================
//= Release allocated memory                                                =
//===========================================================================
void FreeXi(double *** xi, int T, int N)
{
  int t;
  for (t = 1; t <= T; t++)
    free_dmatrix(xi[t], 1, N, 1, N);
  xi ++;
  free(xi);
}

void free_vector(v,nl,nh)
float *v;
int nl,nh;
{
  free((char*) (v+nl));
}

void free_ivector(v,nl,nh)
int *v,nl,nh;
{
  free((char*) (v+nl));
}

void free_dvector(v,nl,nh)
double *v;
int nl,nh;
{
  free((char*) (v+nl));
}

void free_matrix(m,nrl,nrh,ncl,nch)
float **m;
int nrl,nrh,ncl,nch;
{
  int i;
  for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
  free((char*) (m+nrl));
}

void free_dmatrix(m,nrl,nrh,ncl,nch)
double **m;
int nrl,nrh,ncl,nch;
{
  int i;
  for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
  free((char*) (m+nrl));
}

void free_imatrix(m,nrl,nrh,ncl,nch)
int **m;
int nrl,nrh,ncl,nch;
{
  int i;
  for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
  free((char*) (m+nrl));
}

void free_submatrix(b,nrl,nrh,ncl,nch)
float **b;
int nrl,nrh,ncl,nch;
{
  free((char*) (b+nrl));
}

float **convert_matrix(a,nrl,nrh,ncl,nch)
float *a;
int nrl,nrh,ncl,nch;
{
  int i,j,nrow,ncol;
  float **m;
  nrow=nrh-nrl+1;
  ncol=nch-ncl+1;
  m = (float **) calloc((unsigned) (nrow),sizeof(float*));
  if (!m) nrerror("allocation failure in convert_matrix()");
  m -= nrl;
  for(i=0,j=nrl;i<=nrow-1;i++,j++) m[j]=a+ncol*i-ncl;
  return m;
}

void free_convert_matrix(b,nrl,nrh,ncl,nch)
float **b;
int nrl,nrh,ncl,nch;
{
  free((char*) (b+nrl));
}

//===========================================================================
//= Other functions                                                         =
//===========================================================================
void nrerror(error_text)
char error_text[];
{
  void exit();
  fprintf(stderr,"Numerical Recipes run-time error...\n");
  fprintf(stderr,"%s\n",error_text);
  fprintf(stderr,"...now exiting to system...\n");
  exit(1);
}

double hmmgetrand(void)
{
  return (double) rand()/RAND_MAX;
}

void hmmsetseed(int seed) 
{
  srand(seed);
}
