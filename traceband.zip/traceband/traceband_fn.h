#include <stdio.h>			 // printf() and fprintf()
#include <sys/types.h>   // data types used in system calls
#include <sys/socket.h>  // definitions of structures needed for sockets
#include <netinet/in.h>  // constants and structures needed for internet domain addresses
#include <arpa/inet.h>   // for sockaddr_in and inet_ntoa()
#include <netdb.h>
#include <stdlib.h>      // for atoi() and exit()
#include <unistd.h>      // standard unix functions, like alarm()
#include <string.h>      // memset()
#include <sys/time.h>    // select() 
#include <math.h>
#include <assert.h>
#include <unistd.h>      // close()
#include <signal.h>      // signal name macros, and the signal() prototype
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <limits.h>
#include <float.h>

#define PACKET_SIZE       1500-(20+8) // total size - (MAC+IP+UDP) overhead
//#define PACKET_SIZE       512-(20+8) // total size - (IP+UDP) overhead
#define NUM_TRAINS 	     1
#define PCK_TRAIN	   120
#define INPAIR_GAP_MUL      25 // Gap between packet pairs = INPAIR_GAP_MUL * pair_gap 
#define INTRAIN_GAP_MUL     25 // Gap between packet trains = INTRAIN_GAP_MUL * inpair_gap
#define OFFTIME_MUL         30 // Gap between measurements
#define MAX_NUMPCK     1000000 // Maximun number of probing packets
#define MAXPENDING           1 // Maximum # of connection requests
#define SERVER_PORT       3504
#define PATHCAPACITY 100000000 // 100 Mbps
#define MAX_MSG            100
#define TRUE  1
#define FALSE 0
#define min(a,b) ((a)>(b) ? (b) : (a))
#define max(a,b) ((a)>(b) ? (a) : (b))


typedef struct {
  long num;
  long size;
  struct timeval snd_time;
  struct timeval rcv_time;

  //int size;
  //long seqno;
  //long bunch;
  //long idealgap;
  //long totalpairs;
  //long sendgap;
  //struct timeval t;

} traceband_pkt;

typedef struct {
  long timestamp;
  double av_bw;
  long delta_in;
  long delta_out;
  //int symbol;
} trace;

double get_time(void);
void DieWithError(char *errorMessage);  // Error handling function
void catch_alarm(int sig_num);
void snd_usage(void);
void mysleep(long, struct timeval);
long timeval_diff(const struct timeval *t_now, const struct timeval *t_prev);
double rand_exp(void);
double rand_uniform(int min, int max);
